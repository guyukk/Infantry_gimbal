# G 仓校准代码缺口清单（P09 待写/待修，2026-11-14）

- 板别：G = 云台板（H723）
- 日期：2026-11-14
- run-id：20261114-174009
- 依据：交接文档 P09、D13、P06
- 性质：**只列缺口，不改代码**。每条给：缺口、源码证据、影响（能否安全标定）、建议批次/处置。
- 与 `calibration-manual.md` 的分工：手册写“怎么标”；本文件写“代码层面还缺什么、哪些操作不安全”。

---

## 1. 缺口总表

| # | 缺口 | 源码证据 | 影响 | 建议 |
| ---: | --- | --- | --- | --- |
| G-GAP-01 | HD/GM 写入固定写 108 字节，会把 36..107 清零 | `FLASH_WRITE_BUF_LENGHT`=8+20+72+8=108（`User/APP/calibrate_task.c:118`）；`cali_data_write()` 只填前 36 字节、其余为静态零，再按 27 字写入（`:748-771`） | 未来若把 GYRO/ACC/MAG 记录放到 36 之后，每次 GM 写入都会清掉它们；当前“GM 仅 Yaw”暂时无害 | B05（P09）必须先改这条写入路径或明确禁止在该区放新记录 |
| G-GAP-02 | HD/GM 没有任何布局静态断言 | G 全仓只有 VTM 的 `sizeof==21`（`User/APP/video_transmission_module.h:67`）；`head_cali_t` 是 `__packed`、`gimbal_cali_t` 未 packed，均无尺寸检查 | HEAD=8、GM=20 只是推断；编译器/对齐变化会静默改 ABI | B05 增加 `sizeof(head_cali_t)==8`、`sizeof(gimbal_cali_t)==20` 断言（不改格式） |
| G-GAP-03 | HD/GM 写入无回读、无 CRC，只有 4 字节尾标志 | `cali_data_write()` 直接 erase+write，不读回（`:748-771`）；有效性只看 `cali_done==0x55`（`:697-735`） | 写入失败/位翻转可能仍被当有效；与 Pitch 记录的“写后 memcmp”标准不一致 | B05 补写后回读（不改记录格式） |
| G-GAP-04 | 写函数在 address=0 且 len=0 时可能擦全片（潜在） | `bsp_flash.c:58-62`：`secLast=(address+byte_len-1)/4096`；address=0、len=0 时 `0-1` 下溢为 0xFFFFFFFF，循环会擦大量扇区 | 当前调用者都传非零长度（27 字/5 字），但这是潜在灾难；任何新增调用必须先修边界 | B05（P09 可靠性项）加 `len==0`/地址范围保护 |
| G-GAP-05 | Pitch 记录单扇区、无掉电保护 | 地址 0x1000、单扇区 4 KB（`:258-262`）；写前 erase（`bsp_flash.c:58-65`） | 擦除与写入之间断电会丢记录（magic/CRC 失败→零刚度） | 保持 v1、记为已知风险；双槽留给后续（范围外） |
| G-GAP-06 | Yaw 无新采样流程 | `cali_gimbal_hook(ON)` 直接 `return 0`（`:897-902`）；`RC_cmd_to_calibrate` 的 GM 分支只关蜂鸣器（`:585-593`） | 只能加载/保留历史 Yaw 零偏与范围，**不能现场重标** | B05 只交设计；保持 pending，不恢复撞限位 |
| G-GAP-07 | Pitch 采样 request 只能由调试器写入 | `pitch_dm_cali_status.request` 只在 `pitch_dm_cali_poll()` 里被读并清零（`:359-365`）；全仓无 USB/RC/命令写入点 | 现场必须有 Keil Watch（或等价调试器）才能 request=1/2/3/4；不能作为操作手流程 | 保持现状（P09 允许 Watch 流程），B05 文档写明前置条件 |
| G-GAP-08 | Pitch 运行期只在 `stored_valid=0` 时重试加载 | `pitch_dm_cali_recover()` 条件含 `!stored_valid`（`:333-335`） | 若记录加载成功但机械已变（记录值仍“合法”），运行期不会重新校验/拒绝，只能重新 request=1/2/3 | B05 可加“当前 pos 长期越界→标 stale”的观测，不自动改目标 |
| G-GAP-09 | 采样无超时/自动取消、无“两点同侧”检查 | `pitch_dm_cali_poll()` 只校验反馈、|vel|≤0.2、跨度 0.1..1.5、当前在区间（`:381-414`） | 操作者可能采到同侧两点或忘记 request=4；记录仍可能被保存（只要跨度合法） | B05 可在文档/测试里加“先手动摆到两端”的检查清单；代码层可加结果码但不改格式 |
| G-GAP-10 | 注释仍写内部 Flash 0x080A0000 | `User/APP/calibrate_task.h:30-35` 的注释抄自 C 仓；实际是 W25Q 地址 0（`:132`；`bsp_flash.c:3-5`） | 维护者可能按内部 Flash 去读，得到错误结论 | B05 修注释（不改代码） |
| G-GAP-11 | HEAD 温度不被加热使用；加热目标来自 BMI088 | `get_control_temperature()`（`:508-512`）全仓无调用；`IMU_TempCtrl(BMI088.TempWhenCali, BMI088.Temperature)`（`INS_task.c:169`） | HEAD 记录里的温度字段目前不影响加热；但 `err<=0` 时 CCR4 保持上次值（`INS_task.c:64-66`），存在残留 PWM | B04（P06）按极性证据处理残留；B05 文档纠正“HEAD 温度=加热目标”的说法 |
| G-GAP-12 | 陀螺仪校准未挂入 cali 表 | `cali_hook_fun[]` 只有 head/gimbal（`:254`）；`cali_gyro_hook()` 无调用；`INS_cali_gyro()` 全仓无调用 | 没有持久化 GYRO 记录，也没有运行时零漂采样入口；不能声称“可校准陀螺” | 保持 pending；B05 报告“入口不可用” |
| G-GAP-13 | HD/GM 读取失败后不重试（直到重启） | `cali_data_read()` 读失败→清所有 valid 并 return（`:706-721`）；`cali_param_init()` 只调用一次（`:656-685`） | Flash 临时故障会永久丢有效标志，直到重启；与 Pitch 的 1 s 重试不对称 | B05 可选加一次性重试；不作为本轮必做 |
| G-GAP-14 | 无写入失败计数/持久化错误观测 | `cali_data_write()` 无返回值（`:748`），失败只在 `bsp_flash.c` 返回、无人看；Pitch 用 `result=-5` | 现场无法从变量区分“没写”与“写坏” | B05 可加计数；Pitch 已有 result，HD/GM 没有 |
| G-GAP-15 | Pitch 记录无版本迁移路径 | 只接受 `version==1`（`:309-312`） | 未来 v2 必须同时读 v1；当前没有代码 | 保持 v1；双槽/迁移属范围外 |

---

## 2. 能否安全标定的结论

| 对象 | 当前能否安全标定 | 原因 | 证据 |
| --- | --- | --- | --- |
| Pitch 两点（DM） | **能，但必须调试器 + 机械支撑** | request 只能 Watch 写；无有效记录时零刚度；保存有回读与 CRC | `calibrate_task.c:357-442`；`yaw_pitch_direct.c:197-206` |
| Pitch 下限外回收 | **能，只向内** | 0.02 窗口/0.0005 步长，delta<0 强制 0 | `yaw_pitch_direct.c:242-275` |
| Yaw 零偏/范围 | **只能读旧记录，不能重标** | GM 自动校准禁用、无新流程 | `calibrate_task.c:585-593`、`:897-902` |
| HD/GM 记录 | **不能可靠重写** | 写入清 36..107、无回读/CRC、无布局断言 | G-GAP-01/02/03 |
| 陀螺零漂 | **不能** | 未挂 cali 表、`INS_cali_gyro` 无调用 | G-GAP-12 |
| IMU 加热 | **不能判定方向，残留 PWM** | 目标来自 TempWhenCali；err<=0 不更新 CCR4；极性无证据 | G-GAP-11、`hardware-unknowns.md` 1.5 |

---

## 3. 建议批次归属（不实施）

1. **B05（P09）**：G-GAP-01/02/03/04/10/13/14/15——写入边界与回读、布局断言、注释纠正、错误观测。
2. **B04（P06）**：G-GAP-11——加热残留与极性证据；正式源不得在无证据时反转方向。
3. **保持 pending/需用户决定**：G-GAP-05/06/07/08/09/12。
4. **不改**：记录地址 0x1000、magic/version/CRC 格式、`PITCH_DM_ZERO_OFFSET_RAD`、投影开关。

---

## 4. 与交接文档的对应

| 交接条目 | 本文件缺口 | 说明 |
| --- | --- | --- |
| P09 “G 旧 packed 写法有编译警告……必须由当前 ARMCC 生成 sizeof/offsetof 证据” | G-GAP-02 | 当前没有断言；B05 补体积断言 |
| P09 “新 Pitch 记录保留 CRC/版本、写后回读与恢复，单扇区掉电风险显式保留” | G-GAP-05（已实现部分） | 记录 v1 已有 CRC/回读；掉电风险保留 |
| P09 “旧 Flash 写函数的重复擦除、忽略返回值、零长度边界作为独立可靠性项修复” | G-GAP-03/04/14 | 写函数会先擦后写；零长度下溢是潜在项 |
| P09 “旧读取记录增加不改变 ABI 的值域检查” | G-GAP-08 | 可加运行期观测，不改 ABI |
| P06 “温控方向与残留 PWM” | G-GAP-11 | 与加热极性一起 pending |
