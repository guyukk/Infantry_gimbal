# H723 云台板校准手册（现车可独立使用版，2026-11-14）

- 板别：G = 云台板（STM32H723VGTx）
- 日期：2026-11-14
- run-id：20261114-174009
- 依据：交接文档 v1.0 第 3 章 P09 第 1~7 条、1.7 节；D13（先交手册与存储自检，不迁移 Flash、不改机械零位、不启用投影、不新增 Yaw 自动端点校准）
- 方法：所有事实性数据来自当前源码；没有接线/设备证据的写“待确认（需设备）”。
- 适用范围：本车的 Yaw（DJI 6020，CAN2/0x205）、Pitch（DM J4310，CAN2/0x53）、BMI088 IMU 与加热。底盘校准在 C 仓文档。

---

## 0. 安全前提（先读）

1. Pitch 是 DM MIT 位置控制。**没有有效校准记录时位置刚度=0**（见第 4 节），机构必须有支撑或处于不会自由下坠的姿态，才能上电。
2. 两点采样只“记录当前位置”，固件不会驱动电机去采样点（`pitch_dm_cali_poll()` 不调用任何电机控制，G `User/APP/calibrate_task.c:357-442`）。因此采样必须**手动把云台摆到两个端点**，且两个端点都要在机械行程内、留有余量。
3. 不要在未知行程的情况下用大 KP/大电流“找限位”。本手册不提供撞限位流程。
4. 校准写 Flash 是单扇区、无掉电保护的（第 5.6 节），写入过程中断电可能丢记录；写入前先记录旧值。
5. 任何宏/参数修改都要重新编译烧录；改完做第 6 节验收。

---

## 1. 轮位 / 电机 ID / 索引 / 方向图（G 不适用）

G 板不驱动底盘轮电机。源码里虽然有 `User/ROBOT/Infantry_robot.h` 的一套底盘参数（`CHASSIS_X_CHANNEL`、`M3505_MOTOR_SPEED_PID_*`、`CHASSIS_6020_INIT_ANGLE_0..3` 等，`Infantry_robot.h:11-90`），但：

- G 没有任何 `chassis_task`、没有 3508/6020 的 CAN 收发（`can_bsp.c` 里 `CAN_cmd_chassis()` 与 `CAN_cmd_chassis_6020()` 均存在但**无调用者**，见 `User/Bsp/can_bsp.c:168-200`）。
- 交接文档 1.5 明确“G 的 Infantry_robot.h 中仍有一套过期底盘参数，不可复制到 C”。

结论：G 的校准手册不覆盖轮位/零偏；底盘部分见 C 仓文档。G 里的底盘宏只作为“历史遗留”，不要用来反推 C 的参数。

---

## 2. G 外部 Flash：HD / GM 旧记录（只读兼容）

### 2.1 器件与地址

| 项目 | 值 | 来源 |
| --- | --- | --- |
| 器件 | W25Q 系列，OCTOSPI2，4 KB 扇区 / 256 B 页 | `User/Bsp/bsp_flash.c:3-5`；`Core/Src/octospi.c:42-52` |
| 逻辑基址 | `FLASH_USER_ADDR = 0x000000` | `User/APP/calibrate_task.h:132` |
| HD/GM 记录 | 从 0 开始，顺序 HD → GM | `calibrate_task.c:244-252`、`:697-735` |
| Pitch DM 记录 | 0x1000 起的独立 4 KB 扇区 | `calibrate_task.c:258-262` |

注意：`User/APP/calibrate_task.h:30-35` 的注释仍然写“0x080A0000 内部 Flash”，这是从 C 仓拷来的**过期注释**，与 G 的实际实现（W25Q 外部 Flash、地址 0）矛盾。以代码为准。

### 2.2 HD/GM 布局

| 记录 | 偏移 | 长度 | 结构 | 来源 |
| --- | ---: | ---: | --- | --- |
| HEAD 数据 | 0 | 8 | `head_cali_t`（`__packed`：self_id、firmware_version、temperature、latitude） | `calibrate_task.h:186-194` |
| HEAD 尾 | 8 | 4 | name[3]+cali_done | `cali_sensor_t`，`calibrate_task.h:175-183` |
| GM 数据 | 12 | 20 | `gimbal_cali_t`（yaw_offset、pitch_offset、yaw_max/min、pitch_max/min） | `calibrate_task.h:196-204` |
| GM 尾 | 32 | 4 | name[3]+cali_done | 同上 |

`FLASH_WRITE_BUF_LENGHT = sizeof(head)+sizeof(gimbal)+sizeof(imu)*3+CALI_LIST_LENGHT*4`（`calibrate_task.c:118`）。`CALI_LIST_LENGHT=2`（只 HD、GM），但公式里仍加 3 个 `imu_cali_t`（72 字节），因此缓冲=8+20+72+8=108 字节。

写入时（`cali_data_write()`，`:748-771`）：

1. 只把 HD（8+4）与 GM（20+4）拷进缓冲前 36 字节；
2. 其余 72 字节是 `static` 缓冲的零初值，**会被一起写进 Flash 并因此清零**；
3. 先擦 1 个扇区（4 KB），再按 27 个字（108 字节）写。

结论：当前固件每次执行 `cali_data_write()`，都会把 `0x24..0x6B`（36..107）写成 0。若将来把 GYRO 记录放到 36 偏移（C 的布局），这段会被本函数清掉。这一点必须写进任何“补 GYRO 记录”的设计里。

### 2.3 读取与有效标志

`cali_data_read()`（`:697-735`）顺序读取：

- 读 `flash_len*4` 字节到 `head_cali`/`gimbal_cali`（直接读进全局）；
- 读 4 字节尾：`name[0..2]` 与 `cali_done`；
- 任一读失败 → `calibration_flash_ready=0`，并把所有 `cali_done` 清零（`:706-721`）。

`cali_param_init()`（`:656-685`）：

1. `flash_init()` 成功才读；
2. 对 `cali_done == 0x55` 的记录调用 hook 的 `CALI_FUNC_CMD_INIT`；
3. GM 未标定时，`cali_data_read` 会置 `cali_cmd=1` 触发校准（`:730-733`），但 `cali_gimbal_hook(ON)` 现在直接 `return 0`（`:897-902`），所以什么也不会发生，每 1 ms 重试。

### 2.4 GM 记录的作用（只应用 Yaw 字段）

`cali_gimbal_hook(INIT)`（`:886-896`）→ `set_cali_yaw_hook(yaw_offset, yaw_max_angle, yaw_min_angle)`（`User/gimbal/yaw_pitch_direct.c:621-627`）：

```c
gimbal_control.gimbal_yaw_motor.offset_ecd = yaw_offset;
gimbal_control.gimbal_yaw_motor.max_relative_angle = max_yaw;
gimbal_control.gimbal_yaw_motor.min_relative_angle = min_yaw;
```

GM 里的 `pitch_offset`、`pitch_max_angle`、`pitch_min_angle` 三个字段**保留占位但不应用**（旧 DJI Pitch 已退出）。不要因为结构里有这三个字段就认为 Pitch 限位来自 GM。

### 2.5 旧的自动 GM 校准：已禁用

`RC_cmd_to_calibrate()` 的 GIMBAL 分支（`:585-593`）只关蜂鸣器，不再驱动机构；`cali_gimbal_hook(ON)` 返回 0。交接文档“G Yaw 旧自动校准已禁用”与源码一致。**本轮不恢复旧双轴撞限位**。

### 2.6 没有编译期布局检查（与 C 不同）

C 仓有 `head_cali_t==8`、`gimbal_cali_t==20`、`imu_cali_t==24`、GYR 偏移 36 四条静态断言（C `application/calibrate_task.c:16-19`）。G 仓**没有任何这类断言**（全仓 grep 只有 VTM 的 `sizeof==21` 一条，`User/APP/video_transmission_module.h:67`）。`head_cali_t` 在 G 用 `__packed`，理论上 8 字节，但未经编译期验证；`gimbal_cali_t` 未 packed，当前编译器的对齐下是 20 字节，同样无断言。

这是 P09 要求“增加布局断言”的直接缺口；B05 要新增断言后再声称 ABI 固定。

---

## 3. Yaw 校准（G）

### 3.1 记录如何加载、范围与零偏的作用

- 加载：第 2.4 节。`yaw_offset` 写入 `offset_ecd`，`yaw_max/min` 写入 `max_relative_angle/min_relative_angle`。
- `offset_ecd` 只在 `motor_ecd_to_angle_change(ecd, offset_ecd)` 里使用（`gimbal_task.c:165-179`），把编码器读数变成以零偏为原点的相对角。
- `max/min_relative_angle` 只在 `gimbal_relative_angle_limit()` 里做 clamp（`gimbal_task.c:218-249`）。ENCODE 模式下 `relative_angle_set` 会被夹到这两个值。
- GYRO 模式（跟随/小陀螺）用 `INS.YawTotalAngle`，不受 `offset_ecd` 影响（`yaw_pitch_direct.c:427`）。

### 3.2 当前 Yaw 的启动行为（不要当成回零）

`gimbal_set_control()` 在 INIT 且 `gimbal_motor_mode==ENCODE` 时（`yaw_pitch_direct.c:529-556`）：

- 若 Yaw 反馈不存在或 `last_fdb_time` 超过 `YAW_INIT_FEEDBACK_TIMEOUT_MS=100`（`Infantry_robot.h:167`）→ 清 `yaw_init_hold_valid`；
- 否则第一次有效反馈时把 `relative_angle_set = relative_angle`、清两个 PID、置 `yaw_init_hold_valid=1`；
- 控制循环在 INIT 且 hold 无效时直接给 0 电流（`:591-597`）。

即：**Yaw 在 INIT 里保持“当前角”，不自动去中点，也不自动找零偏**。这是 `Yaw初始化限幅导致回零-2026-11-07` 之后的现状，不要在 B05 里“补一个回零”。

### 3.3 新的采样流程：当前没有，只交设计

- 当前没有 Yaw 新采样入口：`RC_cmd_to_calibrate()` 的 Yaw/GM 分支不采样（`:585-593`），`cali_gimbal_hook(ON)` 返回 0。
- 设计（本轮不实施，≤5 行）：在 `gimbal_cali_t` 之外新增独立记录（避免改 GM 的 20 字节 ABI）；采样条件=Yaw 反馈有效且 `|gyro_z|` 小于阈值；需要用户手动摆到两个端点；保存前校验跨度与方向；写入前保留旧值并可回滚；**不恢复碰撞限位**。

---

## 4. Pitch（DM J4310）校准

### 4.1 首次无记录时的状态

`gimbal_init()`（`yaw_pitch_direct.c:331-387`）：

- 默认范围 `pitch_min_raw=-2.5f`、`pitch_max_raw=-2.0f`（`:334-335`）；
- `pitch_dm_cali_status.stored_valid=0`（`:342`）；
- 调 `pitch_dm_cali_load(&pitch_min_raw,&pitch_max_raw)` 尝试覆盖（`:345`）；
- `osDelay(100)` 后首次 `Motor_enable(&GIMBAL_CAN, 0x53)`（`:358-359`）。

无有效记录时：

- `pitch_dm_send_mit()` 要求 `stored_valid` 才允许 `can_hold`（`:204`），因此 MIT 帧的 `POS/VEL/TOR=0、KP=0、KD=0`（`:281-288`）→ **零刚度、零阻尼、零力矩**。机构必须有支撑。
- 默认区间 `[-2.5,-2.0]` 只是“观察区间”，不是机械限位、不是验收限位（`:334-335`）。

### 4.2 有记录时的操作边界

- 记录加载或采样成功后，`pitch_dm_apply_calibration()` 把 `min_raw/max_raw` 转成 `min_relative_angle/max_relative_angle`（`:63-79`），并把当前目标设为当前位置。
- `pitch_dm_send_mit()` 每个周期把目标夹在 `[min_pos, max_pos]`（`:252-254`）。
- 进入 MIT 的条件（`:197-206`）：反馈新鲜（≤100 ms）、反馈状态允许、`confirmed`（或窄条件 state/id）、`stored_valid`、遥控新鲜且合法（`pitch_dm_rc_ready()`）、`pos` 非 NaN。
- 首次有效目标从**本次上电的反馈位置**起步（`:212-227`），不自动去中点。

### 4.3 使能重试

`pitch_dm_enable_ready()`（`:81-144`）：

- 首次 `Motor_enable` 在 `gimbal_init`；
- 未确认时按 `PITCH_DM_ENABLE_FIRST_RETRY_MS=2000`（第一次重试）后改为 `PITCH_DM_ENABLE_RETRY_MS=500`；
- 最多 `PITCH_DM_ENABLE_MAX_ATTEMPTS=8` 次，超过置 `exhausted=1`；
- 已确认后若反馈超时或 `state!=1`，会**清零并重新计数**（`:94-107`），要求新的使能交换。

### 4.4 状态 5 的窄兼容

`pitch_dm_feedback_allows_mit()`（`:146-158`）：只接受 `state==1`，或 `PITCH_DM_CAN_ID==0x53 && fdb.id==3 && fdb.state==5`。这个窄条件只用于“允许发 MIT”，**不能确认使能**（`:199-203` 里还要 `confirmed` 或 `attempts>=2`）。不要扩大到任意 `state==5`。

---

## 5. 两点采样：request / result / 保存 / 回读 / 重启恢复

### 5.1 操作接口（Keil Watch 写变量）

`pitch_dm_cali_status_t`（`User/APP/calibrate_task.h:228-240`，定义在 `calibrate_task.c:272`）：

```text
request       : 0 空闲；1 采样第一点；2 采样第二点；3 校验并保存；4 取消未保存采样
captured      : bit0 第一点已采；bit1 第二点已采
stored_valid  : 1 表示当前运行已应用有效范围
init_done     : gimbal_init 完成
result        : 0 空闲；1 已采样；2 已保存并应用；负数为拒绝原因
first_pos / second_pos / min_pos / max_pos : rad（DM 输出轴原始位置）
```

流程（`pitch_dm_cali_poll()`，`calibrate_task.c:357-442`）：

1. 写 `request=1`，手动把 Pitch 摆到第一个端点，静止（`|fdb.vel| ≤ 0.2 rad/s`）。成功→`captured|=1`、`result=1`、`first_pos=fdb.pos`。
2. 写 `request=2`，摆到第二个端点，静止。成功→`captured|=2`、`result=1`、`second_pos=fdb.pos`。
3. 写 `request=3`：要求 `captured==3`；计算 `min/max`；校验跨度与范围；校验当前 `fdb.pos` 在 `[min,max]` 内；写 Flash；回读 memcmp；应用；清 `captured`；`result=2`。
4. 写 `request=4`：清 `captured`、`result=0`；**不擦旧记录、不恢复默认**。

### 5.2 错误码（逐条）

| result | 含义 | 触发条件（源码） | 位置 |
| ---: | --- | --- | --- |
| 1 | 已采样 | request 1/2 且反馈/静止校验通过 | `:381-401` |
| 2 | 已保存并应用 | request 3 全部通过并回读一致 | `:434-441` |
| -1 | 反馈无效/过期/状态不允许 | `last_fdb_time==0`、>100 ms、或 state 既非 1 也不满足窄条件 | `:372-380` |
| -2 | 运动或位置非法 | `pos/vel` 非有限，或 `|vel|>0.2` | `:383-388` |
| -3 | 两点不齐 | request 3 时 `captured != 3` | `:402-406` |
| -4 | 区间不安全或当前不在区间 | 跨度不在 0.1..1.5、边界超 ±12.5、当前 `pos` 不在 `[min,max]` | `:407-414`、`:289-295` |
| -5 | Flash 失败 | `flash_init` 失败、写失败、回读不一致 | `:415-433` |

### 5.3 校验规则

`pitch_dm_cali_valid_range()`（`:289-295`）：

```text
isfinite(min) && isfinite(max)
min > -PITCH_MIT_P_MAX(-12.5) 且 max < +12.5
span = max-min 在 [0.1, 1.5] rad
```

以及当前 `fdb.pos` 必须落在 `[min,max]` 内（`:409-410`）。这些是“记录合法性”规则，不是机械行程验收标准。

### 5.4 记录格式（v1）

| 字段 | 类型 | 说明 | 来源 |
| --- | --- | --- | --- |
| `magic` | uint32 | `0x50444D31`（ASCII "PDM1"） | `calibrate_task.c:260` |
| `version` | uint32 | 1 | `:261` |
| `min_pos` | float | 端点较小值，rad | `:263-270` |
| `max_pos` | float | 端点较大值，rad | 同上 |
| `check` | uint32 | CRC32（反射多项式 0xEDB88320，初值 0xFFFFFFFF，末尾取反），覆盖前 16 字节 | `:274-287` |

地址 `0x1000`，单扇区 4 KB（`:258-259`）。记录共 20 字节。

### 5.5 保存与回读

`pitch_dm_cali_poll()` 的 request=3 分支（`:417-433`）：

1. 组记录、算 CRC；
2. `flash_write_single_address(0x1000, record, 5)`（先擦所在 4 KB 扇区，再写）；
3. 立即 `flash_read()` 回读；
4. `memcmp(readback, record, 20)`；
5. 全部一致才 `result=2`；任一步失败 `result=-5`，**旧运行限位不变**（因为 `pitch_dm_apply_calibration` 还没调用）。

### 5.6 断电风险（明确保留）

单扇区写入，擦除与写入之间断电会导致记录丢失（magic/CRC 校验失败 → `stored_valid=0`）。本轮不做双槽 v2（D13/范围外），只在报告里保留该风险。

### 5.7 重启恢复

两条路径：

1. 启动加载：`gimbal_init()` → `pitch_dm_cali_load()`（`yaw_pitch_direct.c:345`）→ 仅当 magic/version/CRC/范围全通过才 `stored_valid=1`（`calibrate_task.c:315-324`）。
2. 运行期重试：`pitch_dm_cali_recover()`（`:326-355`），条件为 `init_done && !stored_valid && request==0 && captured==0` 且距上次尝试 ≥ `PITCH_DM_CALI_RETRY_MS=1000`；重新读记录，并且要求 **Pitch 反馈新鲜**、`pos` 在 `[record.min-0.02, record.max]` 内，才在临界区内 `pitch_dm_apply_calibration()` 并置 `stored_valid=1`。

所以“启动时 Flash 读失败、运行中恢复”是存在的；历史候选表里“没有 pitch_dm_cali_load 调用”已过时。

---

## 6. 端点 ≠ 机械零位，以及投影 / 下限外回收

### 6.1 两点端点不是机械零位

- `PITCH_DM_ZERO_OFFSET_RAD = 0.0f`（`Infantry_robot.h:139`）；`pitch_dm_raw_to_relative()` 与反向变换都只是加减这个偏移（`yaw_pitch_direct.c:30-46`）。当前偏移为 0，即“原始位置 = 相对位置”。
- 采样得到的 `min/max` 是两个手动端点，**不代表水平零位**。云台“水平”仍由机械装配和 `INIT_PITCH_SET=0`（`Infantry_robot.h:172`）与 IMU 的关系决定；两者没有自动对齐。
- 因此不要把 `min/max` 的中点当作 0 rad，也不要用它去改 `PITCH_DM_ZERO_OFFSET_RAD`（本轮禁止）。

### 6.2 Yaw 陀螺仪投影保持关闭

`PITCH_DM_YAW_GYRO_PROJECTION_ENABLE = 0`（`Infantry_robot.h:141`）。`gimbal_feedback_update()` 里该宏为 0 时 Yaw 角速度直接取 IMU Z 轴（`yaw_pitch_direct.c:437-442`）。启用投影需要机械零位先对齐，属范围外。

### 6.3 下限外单向回收（只向内）

`pitch_dm_send_mit()`（`:207-275`）：

1. 若 `pos < min_pos - 0.02`（`PITCH_DM_LOWER_RECOVERY_RAD=0.02`）→ `can_hold=0`，本周期零刚度（`:207-211`）。
2. 若 `pos` 在 `[min-0.02, min)` 之间 → `lower_recovery=1`，目标只能向内：
   - 第一帧（`just_seeded`）保持实测位置；
   - 否则目标向 `min_pos` 靠近；
   - 步长上限 `PITCH_DM_RECOVERY_POS_STEP_RAD=0.0005`，且 `delta<0` 时强制 0（`:258-262`）——**不允许继续向外**。
3. 正常区间内步长上限 `PITCH_MIT_MAX_POS_STEP_RAD=0.002`（`:263-267`）。

“只向内”是当前代码的硬约束，不要为了“回中更快”改大窗口或步长。

---

## 7. IMU：固定偏置、Mahony 启动偏置、温控

### 7.1 BMI088 固定偏置（校准参数来自驱动头文件）

`User/Devices/BMI088/BMI088driver.h:48-54`：

```text
GxOFFSET = -0.000681414269
GyOFFSET = -0.00134240754
GzOFFSET = -0.00143384014
AxOFFSET =  0.299675316
AyOFFSET =  0.0720675737
AzOFFSET =  0.0            // Z 轴不减去零漂，因为包含重力
gNORM    =  9.84484291
```

`main()` 里 `BMI088_init(&hspi2, 0)`（`Core/Src/main.c:158`），第二参数 `calibrate=0`，即**不执行上电自动校准**，直接用上述固定偏置。温度换算 `BMI088_TEMP_FACTOR=0.125`、`BMI088_TEMP_OFFSET=23.0`（`BMI088driver.h:20-21`）。

### 7.2 Mahony 启动 Z 轴偏置采样

`INS_task()`（`User/APP/INS_task.c:73-175`）：

- `INS_Init()` → `mahony_init(&mahony, 1.0f, 0.0f, 0.001f)`（`:54`），Kp=1.0、Ki=0、dt=0.001。
- 前 3000 次循环只累加 `ins_time`；`ins_time<1000` 时调 `mahony_calibrate_gyro_bias(&mahony, BMI088.Gyro[Z], 1000)`（`:160-164`）。
- 该函数实现是 `sum += get_gyro; gyro_z_bias = sum / samples;`（`User/Algorithm/mahony/mahony_filter.c:137-145`），`samples` 固定 1000 → 1000 次调用后得到 Z 轴均值偏置。
- `ins_time>3000` 才置 `INS.ins_flag=1`（`:133-135`），`INS_angle` 此时才更新。`gimbal_behaviour` 的 INIT 分支用 `INS.ins_flag` 决定是否允许 Pitch 运动（`gimbal_behaviour.c:231`、`:341-344`）。

注意：`ins_time` 是循环次数（每圈 `osDelay(1)`），不是实测毫秒；DWT 的 `ins_dt` 只用于 Mahony 积分。这个“约 1 s 采样、约 3 s 就绪”是名义值，实际取决于任务调度。

### 7.3 温控（G 的现状，P06 相关）

`IMU_TempCtrl(float ref, float set)`（`User/APP/INS_task.c:59-71`）：

```c
err_ll = err_l; err_l = err; err = set - ref;
if (err <= 0) { return; }                    // 不更新 CCR4
out = KP*err + KI*(err+err_l+err_ll) + KD*(err-err_l);
if (out > MAX_OUT) out = MAX_OUT;
if (out < 0) out = 0;
htim3.Instance->CCR4 = (uint16_t)out;        // TIM3 CH4, PB1
```

参数：`KP=100`、`KI=50`、`KD=10`、`MAX_OUT=500`（`:26-29`）；调用为 `IMU_TempCtrl(BMI088.TempWhenCali, BMI088.Temperature)`（`:169`），即 `ref=TempWhenCali`（目标）、`set=Temperature`（实测），所以 `err = 实测 - 目标`。

事实性风险（P06）：

1. 目标来自 `BMI088.TempWhenCali`（驱动在初始化时读到的温度，见 `BMI088driver.h:63`），**不是** `DES_TEMP=40.0f`（`:25`，全文件未使用）。
2. `err<=0`（未到目标）直接 return，**CCR4 保持上一次值**；从过温回到未达温时不会主动降为 0，存在残留 PWM。
3. 温度高于目标时 `err>0`，输出增大 → 继续加热。方向是否为“正 PWM 加热”取决于外部 MOS 极性，**源码无法证明**。
4. 调用节拍：`IMU_Temp_Cnt>1000` 才调用一次（`:166-171`），约每 1001 圈一次，不是固定 1 ms。

P06 本轮的正确处理：不盲目反转符号。必须先有极性证据，否则只交“计算与输出分离”的候选补丁，正式源保持现状并标 `pending_hardware`。

### 7.4 未挂入 cali 表的 gyro hook

`INS_cali_gyro()`（`:262-281`）存在，但 G 没有任何调用者：`cali_gyro_hook()`（`calibrate_task.c:836-866`）没有被挂到 `cali_hook_fun[]`（数组只有 `cali_head_hook`、`cali_gimbal_hook`，`:254`）。所以“陀螺仪校准”不是可用入口；不要把它写成可操作流程。

---

## 8. 存储自检（离线，可执行）

1. 用调试器/烧录器读 W25Q 地址 0 起 108 字节与 0x1000 起 20 字节，记录原值与 SHA256。
2. HD：检查 8..11 的 `cali_done==0x55`；GM：检查 32..35 的 `cali_done==0x55`。
3. Pitch：检查 `magic==0x50444D31`、`version==1`、`check` 与按第 5.4 节算法算出的 CRC32 一致、`min<max`、跨度 0.1..1.5、边界在 ±12.5 内。
4. 上述任一失败：对应记录视为无效；Pitch 将回到“零刚度”状态（第 4.1 节），不要在这种状态下上电做位置控制。
5. 自检只读，不擦不写。

---

## 9. 设备验收（全部 not_run）

| 编号 | 项目 | 步骤要点 | 通过判据 |
| --- | --- | --- | --- |
| H-G1 | Pitch 零刚度上电 | 无记录状态，支撑机构，上电观察 | 机构不下坠、无抖动、`stored_valid=0`、MIT 帧 KP=KD=0 |
| H-G2 | 两点采样 | request=1/2，手动摆端点，静止 | `result=1`，`captured=3`，`first/second_pos` 合理 |
| H-G3 | 保存与回读 | request=3 | `result=2`；断电重启后 `stored_valid=1`、`min/max` 不变 |
| H-G4 | 区间外拒绝 | 当前 pos 在区间外时 request=3 | `result=-4`，旧记录不变 |
| H-G5 | 取消 | request=4 | `captured=0`、`result=0`、旧记录仍有效 |
| H-G6 | 下限外回收 | 手动推到 min 以下 0.02 内/外 | 0.02 外零刚度；0.02 内只能向 min 靠近，不继续向外 |
| H-G7 | Yaw 保持 | 上电进 INIT，观察 Yaw | 保持当前角，不自动回零 |
| H-G8 | IMU 加热极性 | 低温/常温/过温三点，示波器看 PB1 与温度 | 见 P06：先确认极性再判定 |
| H-G9 | Flash 读写 | 写入后回读、断电重启 | 记录保持；写入过程断电的风险单独记录 |

---

## 10. 与交接文档 v1.0 的差异

| # | 原陈述 | 当前事实 | 证据 | 影响 |
| --- | --- | --- | --- | --- |
| CALG-D1 | 1.7：“G 外部 Flash sector 0：HD/GM 旧记录，GM 仅 Yaw 字段进入当前控制” | 属实；补充：写入函数会把 36..107 字节清零（公式保留了 3×imu 的空间但从不填充） | `calibrate_task.c:118`、`:748-771` | 将来补 GYRO 记录必须改这条写入路径，否则每次 GM 写入会清掉 GYRO |
| CALG-D2 | 1.7：“G 旧 packed 写法有编译警告，表中不声称其实际 HEAD 为 8 字节。必须由当前 ARMCC 生成 sizeof/offsetof 证据” | 属实且 G **没有任何布局静态断言**（C 才有） | G `calibrate_task.h:186-204`；全仓 grep 无 `typedef char` 尺寸检查 | P09 要求新增断言；在此之前 HEAD=8 只是推断 |
| CALG-D3 | 1.7：“G Pitch 两点 request=1/2采样，3保存，4取消未提交采样” | 属实；补充 request=4 只清 `captured` 与 `result`，不动 Flash | `calibrate_task.c:366-371` | 与文档一致 |
| CALG-D4 | 1.7：“result=1/2；-1..-5” | 属实，逐条见第 5.2 节 | `calibrate_task.c:378-433` | 无 |
| CALG-D5 | 1.7：“当前恢复包含启动加载和运行期重试。历史候选表里‘没有 pitch_dm_cali_load 调用’已过时” | 属实：启动 `yaw_pitch_direct.c:345`，运行期 `calibrate_task.c:326-355` | 同左 | 不要再按旧候选删恢复逻辑 |
| CALG-D6 | 1.7：“G Yaw：加载历史零位/范围，旧自动校准已禁用” | 属实 | `calibrate_task.c:585-593`、`:886-905`；`yaw_pitch_direct.c:621-627` | 无 |
| CALG-D7 | P09 第 4 条：“Pitch 首次无记录：零刚度且机构需有支撑……不能把默认范围当验收限位” | 属实：默认 -2.5/-2.0 只写进 `min/max_pos` 与 `pitch_dm_cali_status`，`stored_valid=0` 时 MIT 仍为全零 | `yaw_pitch_direct.c:334-345`、`:197-206`、`:281-288` | 验收必须按“零刚度”设计，不是按 -2.5/-2.0 |
| CALG-D8 | P09 第 6 条：“投影开关保持 0；0.02 下限外回收只允许向内” | 属实；步长 0.0005、窗口 0.02、`delta<0` 强制 0 | `Infantry_robot.h:134-141`；`yaw_pitch_direct.c:258-262` | 无 |
| CALG-D9 | P09 第 7 条：“G IMU 固定偏置、Mahony 启动 Z 偏置采样、温控目标及复位语义；不把未挂入 cali 表的 gyro_hook 写成可用入口” | 偏置与 Mahony 属实；温控目标实际是 `BMI088.TempWhenCali`，`DES_TEMP` 未用；`err<=0` 不更新 CCR4（残留）；`INS_cali_gyro` 无调用者 | `INS_task.c:25`、`:59-71`、`:160-171`、`:262-281`、`:166-171`；`calibrate_task.c:254` | P06 只能按“残留 PWM + 极性未知”处理；gyro hook 不可用 |
| CALG-D10 | 1.7：“G 的外部 Flash 0x1000：DM Pitch，magic/version/min/max/CRC32，写后回读；保留记录 v1 和当前扇区” | 属实，20 字节、CRC32 覆盖 16 字节、地址 0x1000 | `calibrate_task.c:258-287`、`:417-433` | 无 |
| CALG-D11 | 1.7 注释：“HEAD 起点 0x080A0000”（G 侧头文件注释） | G 实际是 W25Q 外部 Flash 基址 0；`0x080A0000` 是 C 的内部 Flash，G 代码里没有这个地址 | G `calibrate_task.h:30-35`（注释）vs `:132`、`bsp_flash.c:3` | 文档/注释必须更正，避免维护者按内部 Flash 去读 |

差异共 11 条；影响 B05 的是 CALG-D1、CALG-D2、CALG-D7、CALG-D9。

---

## 11. 明确禁止（本轮）

1. 不改 `PITCH_DM_ZERO_OFFSET_RAD`、不启用 `PITCH_DM_YAW_GYRO_PROJECTION_ENABLE`。
2. 不恢复旧 GM 双轴撞限位、不新增 Yaw 自动端点校准。
3. 不迁移 Pitch 记录到双槽、不改地址 0x1000 与 20 字节格式。
4. 不在没有极性证据时反转 IMU 加热输出。
5. 不把“device 需确认”的项用经验值填上。
