# H723 云台板按键 / 摇杆 / 拨杆映射现状（2026-11-14）

- 板别：G = 云台板（STM32H723VGTx）
- 日期：2026-11-14
- run-id：20261114-174009
- 依据：交接文档 P03/P05/P14/D08/D09、1.4 节
- 方法：逐条源码调用点，标 `文件:行号`；区分“当前有效 / 代码存在但未接入”。
- 边界：只看源码映射，不证明物理遥控器通道与外部线束。

---

## 1. 输入源

| 输入 | 口 | 协议 | 现状 | 证据 |
| --- | --- | --- | --- | --- |
| 遥控器 | UART5，100000/9B/EVEN/2 stop | 18 字节 DBUS（`SBUS_remotor` 未定义走 `#else`） | 有效；但**短帧也被接受** | `Core/Src/usart.c:47-57`；`User/Bsp/bsp_usart.h:59-82`；`User/Bsp/bsp_usart.c:156-161` |
| 图传 VTM | 同 UART5（`RC_TYPE` 机制在 C 侧） | 21 字节帧 | G 侧无 VTM 解包，只有 `vtm_data` 初始化与转发 | `Core/Src/main.c:169`；`User/APP/message_task.c:75-78` |
| USB HS CDC | OTG_HS | uproto/MUX 自定义协议 | 有效：主机 DELTA/开火/底盘/裁判查询、TFmini 上报 | `User/Communication/example/device/comm_app.c`；`gimbal_channel.h:14-20` |
| 键盘/鼠标 | 在 DBUS 帧里（字节 6..15） | 位图 | 有效（部分键有消费者） | `User/APP/remote_control.c:135-147` |
| 板载按键/拨杆 | 无 | — | G 没有独立按键 GPIO | `Core/Inc/main.h:59-79` 只有电源/片选/CAM/SHOOT |

遥控初始化路径：`main` 直接 `HAL_UARTEx_ReceiveToIdle_DMA(&huart5, remote_buff, SBUS_RX_BUF_NUM)`（`Core/Src/main.c:173`）。`remote_control_init()`（`User/APP/remote_control.c:53-56`）**没有调用者**；`RC_Init()` 的函数体整体被注释（`User/Bsp/bsp_rc.c:11-100`）。即 G 的 RC 初始化是 main 里那行裸调用，bsp_rc.c 是死代码。

---

## 2. 通道定义与灵敏度（G）

| 通道/开关 | 宏 | 值 | 用途 | 来源 |
| --- | --- | --- | --- | --- |
| `ch[2]` | `YAW_CHANNEL` | 2 | Yaw 摇杆 | `User/ROBOT/Infantry_robot.h:145` |
| `ch[3]` | `PITCH_CHANNEL` | 3 | Pitch 摇杆 | `:146` |
| `ch[2]` | `WZ_CHANNEL` | 2 | 仅宏，未见 G 内消费者 | `:148` |
| `s[0]` | `GIMBAL_MODE_CHANNEL` | 0 | 云台行为主拨杆 | `:147` |
| `s[1]` | `SHOOT_RC_MODE_CHANNEL` | 1 | 射击拨杆 | `:179` |
| — | `RC_DEADBAND` | 10 | 死区 | `:152` |
| — | `YAW_RC_SEN` | -0.000005 | 摇杆→yaw 角增量 | `:153` |
| — | `PITCH_RC_SEN` | -0.000006 | 摇杆→pitch 角增量 | `:154` |
| — | `YAW_MOUSE_SEN` | 0.00005 | 鼠标 x→yaw 增量 | `:155` |
| — | `PITCH_MOUSE_SEN` | 0.00015 | 鼠标 y→pitch 增量 | `:156` |

解析（`User/APP/remote_control.c:121-149`）：`ch[0]=(b0|b1<<8)&0x7ff`、`ch[1]`、`ch[2]`、`ch[3]`；`s[0]=(b5>>4)&3`、`s[1]=((b5>>4)&0xC)>>2`；鼠标 6..13；`key.v=b14|b15<<8`；`ch[4]=b16|b17<<8`；随后统一减 1024（`:143-147`）。末尾 `rc_ctrl.last_fdb = HAL_GetTick()`（`:148`）。

关键事实：**`RC_data_is_error()` 在 G 里没有调用者**（全仓只有定义 `:69-113` 和 detect_task 里的注释 `:301-303`）。`slove_RC_lost()` / `slove_data_error()` 同样无调用者。因此 G 当前没有任何“遥控非法值/失联”判定，只有 `last_fdb` 时间戳被 `pitch_dm_rc_ready()` 使用。

---

## 3. 拨杆 → 云台行为

设置函数 `gimbal_behavour_set()`（`User/APP/gimbal_behaviour.c:213-305`），每 1 ms 调用（`gimbal_task.c:117`）。

| `s[0]` | 行为 | 附加条件 | 来源 |
| --- | --- | --- | --- |
| 中档 MID | `GIMBAL_MOTIONLESS`（6） | — | `:263-266` |
| 上档 UP | `GIMBAL_SPIN`（5） | — | `:267-270` |
| 下档 DOWN | `GIMBAL_RELATIVE_ANGLE`（4） | 必须先在 MID 档把 `can_change_to_GIMBAL_RELATIVE_ANGLE` 置 true | `:221-224`、`:271-274` |
| 下档 + X | `GIMBAL_MOTIONLESS`（无力保持） | 键盘覆盖 | `:277-280` |
| 下档 + Shift | `GIMBAL_SPIN` | 键盘覆盖 | `:281-284` |
| 下档 + C | `GIMBAL_RELATIVE_ANGLE` | 同样需要上面那个 latch | `:285-288` |
| 任意 | `GIMBAL_ZERO_FORCE`（0） | `toe_is_error(DBUS_TOE)` 为真 | `:290-293` |

`toe_is_error()` 的现状：`detect_task` 未创建、`detect_hook()` 无调用者、`error_list[]` 为 BSS 零，因此 `toe_is_error()` **恒返回 false**（`User/APP/detect_task.c:72`、`:192-195`、`:207`；`Core/Src/freertos.c` 无 detect 任务）。所以上表最后一行目前永不触发。

行为到电机模式（`gimbal_behaviour_mode_set`，`:79-126`）：

| 行为 | Yaw 模式 | Pitch 模式 |
| --- | --- | --- |
| ZERO_FORCE / CALI / MOTIONLESS | RAW | RAW |
| INIT / ABSOLUTE_ANGLE | ENCODE | ENCODE |
| RELATIVE_ANGLE / SPIN | GYRO | ENCODE |

初始化状态（INIT）：只等 Pitch 到 `INIT_PITCH_SET`（0），Yaw 保持当前位置；退出条件是 `GIMBAL_INIT_TIME=6000` tick、或稳定 `GIMBAL_INIT_STOP_TIME=100` tick，且拨杆不在中档、且遥控未掉线（`:226-260`）。进入 INIT 的条件是“上一次是 ZERO_FORCE 且本次不是”（`:297-304`）——即上电第一次进入任何行为都会先经过 INIT。

---

## 4. 键盘 / 鼠标矩阵（G）

| 输入 | 消费者 | 效果 | 状态 | 来源 |
| --- | --- | --- | --- | --- |
| X | `GIMBAL_ZERO_KEYBOARD` | `s[0]` 下档时 → MOTIONLESS | 有效 | `gimbal_behaviour.h:70`；`gimbal_behaviour.c:277-280` |
| Shift | `GIMBAL_SPIN_KEYBOARD` | `s[0]` 下档时 → SPIN | 有效 | `:69`；`:281-284` |
| C | `GIMBAL_RELATIVE_KEYBOARD` | `s[0]` 下档且 latch 时 → RELATIVE | 有效 | `:71`；`:285-288` |
| F | `TURN_KEYBOARD` | 仅在 ABSOLUTE_ANGLE 模式：掉头 180°，速度 `TURN_SPEED=0.04` | 有效（模式受限） | `Infantry_robot.h:149-150`；`gimbal_behaviour.c:371-404` |
| E | 摩擦轮开关 | 上升沿切换 `STOP <-> READY_FRIC` | 有效 | `shoot_3508.c:175-184` |
| R | 弹舱开 | `shoot_control_loop` 里 R → `Bombbay_on()`；或 `s[1]` 下档且 `s[0]` 中档 | 有效 | `shoot.c:70-72` |
| R | 自瞄开关 | 上升沿切换 `auto_aim_flag`（AIM_OFF↔AIM_ON） | 有效 | `auto_aim.c:217-225` |
| G | 弹舱关 | G → `Bombbay_off()`；或 `s[1]` 中档且 `s[0]` 中档 | 有效 | `shoot.c:73-75` |
| 鼠标左键 | 单发/连发 | 短按单发、长按（`PRESS_LONG_TIME=80` 次循环）连发 | 有效 | `shoot_3508.c:199-217`、`:296-313` |
| 鼠标右键 | Yaw 绝对角 PID 的 kp 切换 56 ↔ 7.2 | 按下变 7.2（“慢速跟随”），松开恢复 56 | 有效 | `shoot_3508.c:315-329` |
| 鼠标 x/y | 云台 yaw/pitch 增量 | `YAW_MOUSE_SEN`、`PITCH_MOUSE_SEN` | 有效 | `gimbal_behaviour.c:368-369`、`:425-426`、`:464-465` |
| W/S/A/D | — | G 无消费者（只被主机底盘注入路径改写通道值，不按键位） | 未接入 | 全仓 grep |
| B | `TEST_KEYBOARD` | 仅宏定义，无消费者 | 未接入 | `Infantry_robot.h:151` |
| Ctrl/Q/V 等 | — | 无消费者 | 未接入 | 全仓 grep |

R 的双重语义（重点）：同一次按键上升沿，`shoot.c:70` 触发弹舱开，`auto_aim.c:219-223` 同时翻转自瞄开关。两处都只看 `key.v & KEY_PRESSED_OFFSET_R`，互不感知。这是交接文档要求“标出 R 与自瞄/弹舱重用”的具体位置。

---

## 5. 射击状态机（拨杆 + 键鼠）

`shoot_set_mode()`（`User/shoot/shoot_3508.c:145-238`）：

| 触发 | 迁移 | 来源 |
| --- | --- | --- |
| `s[1]` 上档上升沿 | `STOP ↔ READY_FRIC` | `:153-161` |
| `s[1]` 离开上档的上升沿，且当前 `READY_BULLET` | → `CONTINUE_BULLET` | `:163-173` |
| E 上升沿 | `STOP ↔ READY_FRIC`（`shoot_mode >= READY_FRIC` 则 STOP） | `:175-184` |
| READY_FRIC 且两轮速度都达 `FRIC_UP*0.95` | → READY_BULLET（`FRIC_UP=4.45`） | `:190-196`、`Infantry_robot.h:217` |
| 左键单击且松手 | → BULLET（单发） | `:202-205` |
| 左键长按或 `s[1]` 下档计时到 `RC_S_LONG_TIME=2000` | → CONTINUE_BULLET | `:207-210`；`Infantry_robot.h:186` |
| 云台行为要求停射（`gimbal_cmd_to_shoot_stop()`） | → STOP | `:231-235`；`gimbal_behaviour.c:196-206` |

单发实现：`shoot_bullet_control()` 用**时间** 415 ms 判定完成，不是角度（`shoot_3508.c:396-417`，`shoot_duaration=415` 在 `:386`）。这与注释“到达角度或超时判断”不一致，也与交接文档 P14 的“单发实际按时间执行却写角度完成”一致。

射击停止链：`shoot_control_loop()` 在 `SHOOT_STOP` 时 `given_current=0` 且 `fric_off()`（`shoot.c:114-118`）；`fric_off()` 两轮共用同一个 `fric_motor_pid`（`shoot_3508.c:62-93`），是 P07 的证据。

摩擦轮温度保护：任一轮 ≥80℃ 或模式为 STOP 时 `CAN_cmd_friction(0,0,0,0)`（`shoot.c:129-146`）。

---

## 6. 主机（上位机）命令路径与 RC 注入

USB 侧 SID（`User/Communication/channel/gimbal/gimbal_channel.h:14-20`）：`STATE=0x0201`、`DELTA=0x0202`、`TFMINI=0x0203`、`REFEREE=0x0204`、`FIRE=0x0205`、`CHASSIS=0x0206`、`REFEREE_QUERY=0x0207`。

| 命令 | 到达路径 | 现状 | 来源 |
| --- | --- | --- | --- |
| DELTA | `gimbal_channel.c:20-33` → `auto_aim_apply_delta_udeg()` + `hooks.on_delta` | 只要收到就接受，**不检查 auto-aim 开关、不检查 status/ts_us**；`last_fdb` 被刷新 | `gimbal_channel.c:20-33`；`auto_aim.c:297-319` |
| FIRE | `gimbal_channel.c:42-53` → `gimbal_on_fire()` | 需 `auto_aim_flag==AIM_ON`，否则直接 return；120 ms 超时；单发用 `ts_us` 去重 / 20 ms 脉冲 | `comm_app.c:390-423`、`:66-68`、`:82-84` |
| CHASSIS | `gimbal_channel.c:55-70` → `gimbal_on_chassis()` | 需 `auto_aim_flag==AIM_ON`；120 ms 超时；**直接改写 `rc_ctrl` 的通道与拨杆** | `comm_app.c:425-436`、`:487-529` |
| REFEREE_QUERY | `gimbal_on_referee_query` | 置查询标志，允许发布裁判状态 | `comm_app.c:438-443`、`:548-560` |

`comm_apply_host_controls()`（`comm_app.c:445-546`）的关键事实：

1. 只有 `aim.auto_aim_flag == AIM_ON` 时才注入（`:451-460`）；关闭时清注入并恢复。
2. 底盘命令把 mm/s、mdeg/s 换算成 RC 通道值，clamp ±660，然后写 `rc->rc.ch[CHASSIS_X_CHANNEL/ Y / WZ]` 和 `rc->rc.s[]`（`:487-529`）。
3. 开火命令把 `SHOOT_ON_KEYBOARD`（=E）写进 `key.v`，并设 `mouse.press_l`（`:531-543`）。
4. 这就是 D08 要禁掉的“主机底盘命令经 RC 注入”路径；当前它是**有效**的，且与真实遥控共享同一个 `rc_ctrl`，谁后写谁生效。

自动瞄准开关与 DELTA 的错位：`gimbal_channel.c:28-32` 明确注释“总是接受主机 DELTA”，而 `auto_aim_control_tick_internal()` 在 `AIM_OFF` 时会清零误差并复位滤波（`auto_aim.c:350-359`），所以 DELTA 在 OFF 时不会驱动输出；但 `last_fdb` 仍被刷新（`:318`），使“超时”永远不成立。

---

## 7. 行为 → 输出链

```text
UART5 RX(18B/短包) -> HAL_UARTEx_RxEventCallback (bsp_usart.c:156)
  -> sbus_to_rc (remote_control.c:121)  [无条件写 rc_ctrl；last_fdb=now]
auto_aim_task 1ms: auto_aim_set(R 开关) -> feedback_update(刷 last_fdb) -> control_tick(PD 整形)
gimbal_task 1ms (gimbal_task.c:109):
  gimbal_set_mode -> gimbal_behaviour_mode_set (gimbal_behaviour.c:79)
  gimbal_mode_change_control_transit (yaw_pitch_direct.c:455)
  gimbal_feedback_update (yaw_pitch_direct.c:408)  [Yaw 用 INS.YawTotalAngle；Pitch 用 DM pos]
  gimbal_set_control (yaw_pitch_direct.c:501)      [behaviour 增量 + 自瞄增量 + 限幅]
  gimbal_control_loop (yaw_pitch_direct.c:576)
  shoot_control_loop (shoot.c:40)
  gimbal_send_cmd (yaw_pitch_direct.c:302)
    -> CAN_cmd_gimbal(yaw,0,trigger,0)  (can_bsp.c:147)
    -> pitch_dm_send_mit(...)           (yaw_pitch_direct.c:180)
```

`gimbal_send_cmd()` 的顶层门是 `if (debug == 0)`（`yaw_pitch_direct.c:304`）。`robot_param.h` 里 `debug=0`（`:47`），所以该分支始终成立；`else` 分支（全 0）不可达。另有一层 `if (!(toe_is_error(YAW) && toe_is_error(PITCH) && toe_is_error(TRIGGER)))`（`:309`）——因为 `toe_is_error` 恒 false，括号内恒真，`!(...)` 恒假？注意：`!(false && false && false) = !false = true`，所以发送继续；真正的意思是“三个都错才不发送”，而当前三个都“不错”，因此始终发送。这层的保护实际不生效（没有任何掉线会触发）。

---

## 8. “当前有效 / 未接入”清单

**当前有效**

1. `s[0]` 三档 + X/Shift/C 覆盖（含 MID 档 latch 才能进 RELATIVE 的隐含约束）。
2. `s[1]` 射击拨杆：上档切摩擦轮、下档触发射击。
3. E 风摩擦轮开关、鼠标左键单发/连发、右键 kp 切换、F 掉头、R 弹舱/自瞄双用、G 弹舱关。
4. 主机 DELTA（只要收到就进控制）、主机 FIRE/CHASSIS（仅 `AIM_ON` 时注入）。
5. `pitch_dm_rc_ready()` 用 `last_fdb` + 100 ms + 通道 ±700 + `s[0]!=0` 做 Pitch MIT 门控（`yaw_pitch_direct.c:160-178`）。

**代码存在但未接入**

1. `RC_data_is_error()`、`slove_RC_lost()`、`slove_data_error()`、`remote_control_init()`、`bsp_rc.c` 全部：无调用者/全注释。
2. `detect_task`、`detect_hook()`、`error_list[]`：未创建、未初始化、无人调用，`toe_is_error` 恒 false。
3. `W/S/A/D`、`B`、`Ctrl/Q/V`：G 内无消费者。
4. `chassis_data`：只写不读（28 字节帧解析结果无下游）。
5. `gimbal_mailbox_set/get`：`set` 在 `comm_app.c:387`，`get` 无调用者（`gimbal_channel.c:265`）。
6. `C` 键的 RELATIVE 分支依赖 MID 档 latch：若上电后从未经过 MID，按下档 + C 不会进入 RELATIVE（行为保持上一次）。这是逻辑事实，不是“未接入”，但属隐性操作约束。

---

## 9. 与交接文档 v1.0 的差异

| # | 原陈述 | 当前事实 | 证据 | 影响 |
| --- | --- | --- | --- | --- |
| GK-D1 | P14：“R 与自瞄/弹舱的重用” | 属实且是同一上升沿双触发：`shoot.c:70` 与 `auto_aim.c:219-223` 各自读 R | 同左 | 改其一必须同时评估另一个；B03 的主机开火仲裁不能碰这个映射 |
| GK-D2 | P03：“当前预期为未定义 SBUS_remotor 的 18 字节分支，需以预处理确认” | 工程宏只有 `USE_HAL_DRIVER,STM32H723xx`，`SBUS_remotor` 未定义 → 走 `#else`：`SBUS_RX_BUF_NUM=36`、`RC_FRAME_LENGTH=18` | uvprojx:342；`bsp_usart.h:59-82` | 可按 18 字节设计，报告需写预处理依据 |
| GK-D3 | P03：“Size <= RC_FRAME_LENGTH 会接受短帧并读取完整帧字段，随后刷新 last_fdb” | 属实 | `bsp_usart.c:158-161`；`remote_control.c:148` | P03 根因明确 |
| GK-D4 | P04/D04：“RC 过期/非法时……保护” | 当前 G **没有任何 RC 非法/失联判定**：`RC_data_is_error()` 无调用者，`toe_is_error(DBUS_TOE)` 恒 false；只有 Pitch MIT 用 `last_fdb` 做 100 ms 门控 | `remote_control.c:69`（无调用）；`detect_task.c:194`；`yaw_pitch_direct.c:160-178` | B03 的 RC 健康必须先“接通”再谈保护；不能假定旧链路在工作 |
| GK-D5 | P05：“主机底盘与开火改写本地 rc_ctrl” | 属实：`comm_apply_host_controls()` 直接写 `rc->rc.ch[]`、`rc->rc.s[]`、`key.v`、`mouse.press_l` | `comm_app.c:487-543` | D08 要禁的是这段；它与真实 RC 无仲裁 |
| GK-D6 | P05：“last_fdb 同时由 RX 和控制循环刷新；debug 不检查超时” | 属实：RX 在 `remote_control.c:148` 与 `auto_aim.c:318` 刷新，控制循环在 `auto_aim.c:261` 每周期刷新；`#if ROBOT_MODE == release` 才检查超时，而 `ROBOT_MODE=debug` | `auto_aim.c:206-216`、`:261`、`:318`；`robot_param.h:53` | 自瞄超时当前永不生效 |
| GK-D7 | 1.4/P05：“DELTA 的 status/ts_us 当前被忽略” | 属实：`auto_aim_apply_delta_udeg()` 显式 `(void)status; (void)ts_us;` | `auto_aim.c:302-303` | 与 P05 第 6 条一致 |
| GK-D8 | P14：“X/C/Shift 与 servo 重用” | G 侧无 servo；G 的 X/C/Shift 只用于云台行为，不与其他执行器冲突 | `gimbal_behaviour.c:277-288` | 该条只适用 C 仓，整车矩阵要分板写 |
| GK-D9 | 1.4：“G 没有创建 detect_task” | 属实，且 `detect_hook` 也无调用者、`error_list` 未初始化 | `detect_task.c:72`、`:192-195`、`:207` | 所有基于 `toe_is_error` 的保护都是空判 |
| GK-D10 | P05：“主机开火/自瞄使用独立命令源和仲裁，不伪造遥控输入” | 当前实现正是“伪造遥控输入”：把 E 键与鼠标左键写进 `rc_ctrl` | `comm_app.c:531-543` | D09 的目标与现状相反，B03 必须换实现而不是微调 |

差异共 10 条；对 B03 直接相关的是 GK-D4、GK-D5、GK-D6、GK-D10。

---

## 10. 待设备确认

1. 遥控器 `s[0]/s[1]` 的物理拨杆与 `RC_SW_*` 数值对应关系。
2. R 键在实际操作中主要被当作“弹舱”还是“自瞄”，两者同时翻转是否被操作手接受。
3. 右键 kp 7.2 的实际手感与是否与自瞄同时使用。
4. `s[1]` 下档触发连发的 `RC_S_LONG_TIME=2000` 是否仍符合当前操作习惯（该计时只在非 STOP 模式累积）。
5. F 掉头只在 ABSOLUTE_ANGLE 模式生效，实际是否会用到该模式（当前拨杆映射中 ABSOLUTE_ANGLE 不被任何拨杆选中，只能通过模式切换逻辑间接触发）。
