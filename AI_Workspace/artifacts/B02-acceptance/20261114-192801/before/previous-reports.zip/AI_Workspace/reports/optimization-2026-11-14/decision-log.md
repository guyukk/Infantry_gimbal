# 决策日志：整车工程优化

run-id：20261114-174009
记录规则：只记本轮新产生的判断（交接文档已定的事项不重复记）。每条包含：判断、依据、影响、可能的反对意见。

## DEC-001：G 当前构建为 33 warnings，不沿用文档的 30

- 判断：以本次实测 33 条为准，并把 30 条标注为 2026-11-07 的历史事实。
- 依据：G HEAD 17880289（2026-11-12）晚于文档引用的构建；2026-11-14 全量编译日志 `B01/build/gimbal.log` 逐行统计 33 条。
- 影响：P12 的目标改为"33 条逐类处置 + 无新增"，不是"回到 30"。
- 反对意见：若决策者认为 11-12 的提交不该带来警告增长，则应先复核该提交内容；本轮不据此改动用户已提交代码的功能逻辑。

## DEC-002：不创建 git 提交，全部改动以未提交状态 + diff 交付

- 判断：C/G 均不 commit、不建新分支；每批用 `changes.diff` + before/after 快照作为可复原证据。
- 依据：交接文档 0.1「不要求为了留证据强制提交用户已有改动」「不得清除未提交工作」；C 存在用户未提交的 AGENTS.md 修改。
- 影响：最终报告给出未提交状态、逐文件哈希与恢复包路径；决策者自行决定是否入库。
- 反对意见：不提交会让 `git diff` 依赖工作树；已用 before/after 源码包 + SHA256 抵消该风险。

## DEC-003：把 vendored unicorn/pyelftools 补到 C 的本地 cache

- 判断：从 G 的 `cache/dependencies/packages` 复制 unicorn 2.1.4 + pyelftools 到 C 同位置，使 C 的 validate_*.py 可执行。
- 依据：C 的验证脚本本来依赖该路径下的 vendored 包，但目录缺失，`--help` 直接 ModuleNotFoundError；本机无 gcc/clang/cl，ARMCC + Unicorn 是唯一可用的离线执行路径。
- 影响：C 的现有 42 项运行期检查恢复可跑；cache 目录不入库，需在报告中说明这是本机环境准备。
- 反对意见：也可 pip 全局安装；但 vendored 路径是工程既定约定，复制更保守。

## DEC-004：新增两个工具脚本（capture_evidence.py、safe_edit.py），不改现有验证脚本语义

- 判断：B00 需要一个不依赖 projects.json 的原始保全工具（此时 projects.json 仍指向坏路径），实现为 `capture_evidence.py`；GBK/UTF-8 混排用 `safe_edit.py` 按原编码写回。
- 依据：交接文档 4.1 第 1 步要求"不先调用已知坏路径的双板 snapshot，分别保存原始字节"；实测 C 有 29 个 GBK 文件，直接用 UTF-8 重写会毁中文注释。
- 影响：工具改动与固件改动在 diff 中完全分离（B01 只含工具）。
- 反对意见：新增工具增加维护面；但两者都无外部依赖、单文件、可独立跑。

## DEC-005：B00 原始包中排除历史大目录，仅建索引

- 判断：`snapshots/`、`cache/`、`artifacts/`、`RTE/`、`Objects/`、`reports/history/` 不进 sources.zip，改为 path/size/mtime 索引；现存 AXF/HEX/MAP/构建日志另行复制进包的 firmware/ 目录。
- 依据：C 无 .git 时 1199 MB、G 2614 MB，全量打包无意义且会淹没源码证据；文档要求"归档明确排除 .git、缓存、历史大快照/构建输出目录，但单独保存现有 AXF/HEX/MAP/日志"。
- 影响：C 包 5.8 MB / G 包 30.8 MB；固件产物单独可校验（含 SHA256）。
- 反对意见：历史快照不在包内；其路径与尺寸索引已在 excluded-index.csv，且历史目录本身不可变。
