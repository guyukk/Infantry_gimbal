# 现车输入、模式与仲裁

B05核对版，2026-11-15；替代旧草稿中“无持续失联保护”“主机可注入RC”等描述。参数未改，源码符号定位优先于旧行号。

## C底盘

ch0左右、ch1前后、ch2旋转，s0主模式：下档默认跟随、中档停止；上档且s1不为下档时旋转，上档+s1下档未赋新模式，会保留前一状态。仅s0下档时X停止、C跟随、Shift旋转，优先级X>C>Shift，见application/chassis_behaviour.c。W/S/A/D覆盖平移目标，保留2.6m/s和软转向参数；目标不等于实际速度。

Z/X/C/V分别给四路servo加PWM，Shift配合改为减PWM；按住按10ms任务循环重复变化。X/C/Shift同时影响底盘模式，输入复用未重映射。RC非法帧不覆盖rc_ctrl，100ms持续保护/新RC恢复由B03负责；servo独立失联策略没有扩展。

## G云台

ch2为Yaw、ch3为Pitch；鼠标x/y给增量。s0中档MOTIONLESS、上档SPIN、下档RELATIVE（需先经过中档的锁存）；下档X/C/Shift覆盖行为，见User/APP/gimbal_behaviour.c。

**MOTIONLESS可能保持MIT位置，不是零刚度入口。** 手动标定按[校准手册](calibration-manual.md)确认最终输出抑制。s1/E控制发射机构就绪/关闭；鼠标左键短按/长按单发/连发，原循环计数阈值不改，本地优先于主机。

R同时打开弹舱并按边沿切换自瞄，G关闭弹舱；输入复用保留。自瞄重新ON要新DELTA，2000ms双模式超时退出并清历史。旧摇杆组合不提供当前自动标定；Pitch只支持Watch request1/2/3/4。

主机不写RC，不支持底盘运动；射击独立请求120ms超时、20ms单发窗口，需本地ready/自瞄ready/必要健康。非零token只与最近一次去重，不是无限历史防重放。

## 状态

RC/电机/IMU按B03最终输出域保护，旧detect任务未启动也不会冒充在线。UI按新鲜线上状态显示，自瞄无字段为UNK，见[接口说明](ui-and-interfaces.md)。本文件不证明接线或动作已实测；B04、B06、B07均等用户确认。
